
import React, { useState } from 'react';
import * as Storage from '../services/storage';
import { Lock, ArrowRight, AlertCircle, User, Instagram, PlusCircle, Activity, Mail, Phone, Users, Eye, EyeOff } from 'lucide-react';

interface LoginProps {
  onLogin: (role: 'ADMIN' | 'CLIENT', userId?: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState('');

  // Login State
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Registration State
  const [regData, setRegData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    gender: 'MALE' as 'MALE' | 'FEMALE',
    dob: '',
    height: '',
    weight: ''
  });

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // Allow empty password if logging in with ID (checked in Storage.authenticate)
    const result = Storage.authenticate(identifier.trim(), password.trim());
    if (result) {
      onLogin(result.role, result.user?.id);
    } else {
      setError('Invalid credentials. If using Email/Phone, password is required. If using ID, ensure it is correct.');
    }
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (regData.password !== regData.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    try {
      const newUser = Storage.createUser({
        name: regData.name,
        email: regData.email,
        phone: regData.phone,
        password: regData.password,
        gender: regData.gender,
        dob: regData.dob,
        height: Number(regData.height),
        currentWeight: Number(regData.weight)
      });
      
      alert(`Account Created Successfully!\n\nYour Unique Login ID is: ${newUser.id}\n\nPlease note: Your subscription is currently INACTIVE. Contact the Admin to activate your plan.`);
      onLogin('CLIENT', newUser.id);
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleForgotPassword = () => {
    window.open("https://www.instagram.com/dreambody997?igsh=MWVvenQ1MzF6eHUyYQ==", "_blank");
  };

  return (
    <div className="min-h-[calc(100vh-200px)] flex items-center justify-center px-4 py-8">
      <div className={`bg-slate-900 border border-slate-800 p-8 rounded-2xl w-full ${isRegistering ? 'max-w-2xl' : 'max-w-md'} shadow-2xl transition-all`}>
        
        <div className="text-center mb-8">
           <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-slate-800 mb-4">
              {isRegistering ? <PlusCircle className="h-8 w-8 text-cyan-500" /> : <Lock className="h-8 w-8 text-cyan-500" />}
           </div>
           <h2 className="text-2xl font-bold text-white">{isRegistering ? 'Start Your Journey' : 'Access Portal'}</h2>
           <p className="text-slate-400 mt-2 text-sm">
             {isRegistering ? 'Create your profile to access elite coaching.' : 'Log in with your unique ID, Email, or Phone number.'}
           </p>
        </div>

        {error && (
             <div className="flex items-center text-red-400 bg-red-900/20 p-3 rounded-lg text-sm mb-6">
                <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
                {error}
             </div>
        )}

        {!isRegistering ? (
          /* LOGIN FORM */
          <form onSubmit={handleLoginSubmit} className="space-y-4">
             <div>
               <label className="block text-xs text-slate-500 mb-1 ml-1">LOGIN ID / EMAIL / PHONE</label>
               <div className="relative">
                  <User className="absolute left-3 top-3.5 h-5 w-5 text-slate-500" />
                  <input 
                    type="text" 
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="Enter ID, Email or Phone"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-3 text-white focus:border-cyan-500 outline-none transition-all placeholder:text-slate-600"
                    required
                  />
               </div>
             </div>

             <div>
               <label className="block text-xs text-slate-500 mb-1 ml-1">PASSWORD</label>
               <div className="relative">
                  <Lock className="absolute left-3 top-3.5 h-5 w-5 text-slate-500" />
                  <input 
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Required if using Email/Phone"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-12 py-3 text-white focus:border-cyan-500 outline-none transition-all placeholder:text-slate-600"
                  />
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-slate-500 hover:text-white"
                  >
                    {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                  </button>
               </div>
               <p className="text-xs text-slate-500 mt-1 ml-1">* Password not required if logging in via ID.</p>
             </div>
             
             <button 
               type="submit" 
               className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg shadow-cyan-900/40 flex justify-center items-center mt-2"
             >
               Login <ArrowRight className="ml-2 h-5 w-5" />
             </button>

             <div className="space-y-3 pt-4 text-center">
                 <button 
                  type="button" 
                  onClick={handleForgotPassword}
                  className="text-slate-500 hover:text-cyan-400 text-sm flex items-center justify-center w-full transition-colors"
                >
                  <Instagram className="h-4 w-4 mr-1" /> Forgot Password / ID?
                </button>
                <div className="text-sm text-slate-500">
                  New here? <button type="button" onClick={() => setIsRegistering(true)} className="text-cyan-500 font-bold hover:underline">Create Account</button>
                </div>
             </div>
          </form>
        ) : (
          /* REGISTRATION FORM */
          <form onSubmit={handleRegisterSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
               <div>
                  <label className="block text-xs text-slate-500 mb-1 ml-1">FULL NAME</label>
                  <div className="relative">
                      <User className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                      <input 
                        required
                        type="text" 
                        value={regData.name}
                        onChange={(e) => setRegData({...regData, name: e.target.value})}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-4 py-3 text-sm text-white focus:border-cyan-500 outline-none"
                      />
                  </div>
               </div>
               <div>
                  <label className="block text-xs text-slate-500 mb-1 ml-1">PHONE NUMBER</label>
                  <div className="relative">
                      <Phone className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                      <input 
                        required
                        type="tel" 
                        value={regData.phone}
                        onChange={(e) => setRegData({...regData, phone: e.target.value})}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-4 py-3 text-sm text-white focus:border-cyan-500 outline-none"
                      />
                  </div>
               </div>
            </div>

            <div>
               <label className="block text-xs text-slate-500 mb-1 ml-1">EMAIL ADDRESS</label>
               <div className="relative">
                  <Mail className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                  <input 
                    required
                    type="email" 
                    value={regData.email}
                    onChange={(e) => setRegData({...regData, email: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-4 py-3 text-sm text-white focus:border-cyan-500 outline-none"
                  />
               </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                 <label className="block text-xs text-slate-500 mb-1 ml-1">PASSWORD</label>
                 <div className="relative">
                    <Lock className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                    <input 
                      required
                      type="password" 
                      value={regData.password}
                      onChange={(e) => setRegData({...regData, password: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-4 py-3 text-sm text-white focus:border-cyan-500 outline-none"
                    />
                 </div>
              </div>
              <div>
                 <label className="block text-xs text-slate-500 mb-1 ml-1">CONFIRM PASSWORD</label>
                 <div className="relative">
                    <Lock className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                    <input 
                      required
                      type="password" 
                      value={regData.confirmPassword}
                      onChange={(e) => setRegData({...regData, confirmPassword: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-4 py-3 text-sm text-white focus:border-cyan-500 outline-none"
                    />
                 </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
               <div>
                  <label className="block text-xs text-slate-500 mb-1 ml-1">DATE OF BIRTH</label>
                  <input 
                    required
                    type="date" 
                    value={regData.dob}
                    onChange={(e) => setRegData({...regData, dob: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white focus:border-cyan-500 outline-none"
                  />
               </div>
               <div>
                  <label className="block text-xs text-slate-500 mb-1 ml-1">GENDER</label>
                  <div className="relative">
                     <Users className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                     <select 
                        value={regData.gender}
                        onChange={(e) => setRegData({...regData, gender: e.target.value as any})}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-4 py-3 text-sm text-white focus:border-cyan-500 outline-none appearance-none"
                     >
                        <option value="MALE">Male</option>
                        <option value="FEMALE">Female</option>
                     </select>
                  </div>
               </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                 <label className="block text-xs text-slate-500 mb-1 ml-1">HEIGHT (CM)</label>
                 <div className="relative">
                    <Activity className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                    <input 
                      required
                      type="number" 
                      value={regData.height}
                      onChange={(e) => setRegData({...regData, height: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-4 py-3 text-sm text-white focus:border-cyan-500 outline-none"
                    />
                 </div>
              </div>
              <div>
                 <label className="block text-xs text-slate-500 mb-1 ml-1">WEIGHT (KG)</label>
                 <div className="relative">
                    <Activity className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
                    <input 
                      required
                      type="number" 
                      value={regData.weight}
                      onChange={(e) => setRegData({...regData, weight: e.target.value})}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-4 py-3 text-sm text-white focus:border-cyan-500 outline-none"
                    />
                 </div>
              </div>
            </div>

            <button 
              type="submit" 
              className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg shadow-cyan-900/40 flex justify-center items-center mt-4"
            >
              Register & Login <ArrowRight className="ml-2 h-5 w-5" />
            </button>

            <div className="text-center pt-2">
               <div className="text-sm text-slate-500">
                  Already have an account? <button type="button" onClick={() => setIsRegistering(false)} className="text-cyan-500 font-bold hover:underline">Login here</button>
               </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default Login;
